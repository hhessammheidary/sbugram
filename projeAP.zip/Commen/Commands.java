package Commen;

public enum Commands {
    Login , SingUp , IsUsernameUnique , ForgetPassword , ChangePassword ,  AddPost , TimeLine ,DeleteAccount
    , SearchUser , GetUserPosts , Like , LikeNumber , AddComment , Repost , ChangeFirstname , ChangeLastname , ChangePhoneNumber
     , ChangeProfileImage ,GetUser , RepostNumber , GetUserProfile , LoadUser , CommentNumber , GetComments,
    Follow , Unfollow , FollowerNumber , FollowingNumber , GetUserWithUsername
}
