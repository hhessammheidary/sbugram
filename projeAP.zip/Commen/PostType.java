package Commen;

public enum PostType {
    Normal , repoost
}
